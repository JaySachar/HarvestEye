#include "mesh_properties.hpp"

namespace rerun::components {
#if 0
    // <CODEGEN_COPY_TO_HEADER>

    static MeshProperties from_triangle_indices(Collection<uint32_t> indices) {
        return MeshProperties(std::move(indices));
    }

    // </CODEGEN_COPY_TO_HEADER>
#endif
} // namespace rerun::components
